Page({
    data:{
        info:[],
        token:"",
        loginId:"",
        zxc:"4134"
    },
    onLoad(query){
        let that=this
         my.getStorage({
        key: 'session',
    success: function(res) {
      that.data.token=res.data.token,
      that.data.loginId=res.data.loginId
    }
    }),
         my.httpRequest({
        url: "http://121.42.44.214:8082/whjtys/vaccine/findAllVaccineInfo?token="+that.data.token+"&loginId="+that.data.loginId, // 目标服务器 url
      success: (res) => {   
          that.data.info=res.data.list
          console.log(that.data.info)
       }
    })
    }
})